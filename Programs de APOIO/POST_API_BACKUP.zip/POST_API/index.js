const express = require('express');
const request = require('request');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json(
    `{
        "name": "sap_http_api",
        "version": "1.0.0",
        "description": "Criar uma Conecção Http para HTTPS SAP",
        "main": "index.js",
        "scripts": {
          "test": "node index.js",
          "dev": "nodemon index.js"
        },
        "author": "Caio DH Consulting",
        "license": "ISC",
        "dependencies": {
          "express": "^4.18.2",
          "nodemon": "^1.19.4",
          "request": "^2.88.2",
          "request-promise": "^0.0.1",
          "require": "^0.4.9"
        }
      }`
));

app.get('/', (req, res) => {
    res.send();
});

app.listen(PORT, () => console.log(`Server running in port ${PORT}`));
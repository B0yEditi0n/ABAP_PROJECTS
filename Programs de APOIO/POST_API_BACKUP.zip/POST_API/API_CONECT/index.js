import express, { request, response } from 'express';
import bodyParser from 'body-parser';
import { HttpApiConnect } from './function/getRequest.js';

/*
 * Rencaminhar o GET
 */
const http = 'https://dh-consulting-sap-api-default-rtdb.firebaseio.com/DHCONSULTING';
const app = express();
const PORT = 5723;

var apiConnect = new HttpApiConnect;

app.use(bodyParser.json());
app.listen(PORT, () => console.log(`Servidor rodando em \nhttp://localhost:${PORT}/DHCONSULTING`));
app.get('/DHCONSULTING', async (req, res) => {
    var formatedJson = await apiConnect.getJson(http + '.json');
    // console.log(req.params);
    // console.log(res.params);
    res.send(formatedJson);    
});
app.get('/DHCONSULTING/:JsonPATH', async (req, res) => {
    const { JsonPATH } = req.params
    var formatedJson = await apiConnect.getJson(`${http}/${JsonPATH}.json`);
    
    if(typeof formatedJson == 'object'){
        res.send(formatedJson);
    }
    else{
        res.send(formatedJson.toString());
    }
    
});

/*
 * Rencaminhar o Post
*/
app.post('/DHCONSULTING', async (request, response) =>{
    console.log('Post')
    console.log('Request:', request.body);
    console.log('Resposta:', response.params);
    
    // Retorno para Função]
    var responsePOST = await apiConnect.postJson(http + '.json', request.body);
    response.json({
        status: 'success'
    });
});
app.post('/DHCONSULTING/:JsonPATH', async (request, response) =>{
    const { JsonPATH } = request.params
    console.log('Post')
    console.log('Request:', request.body);
    console.log('paraetros', JsonPATH)

    var responsePOST = await apiConnect.postJson(`${http}/${JsonPATH}.json`, request.body);
    response.json({
        status: 'success'
    });
});
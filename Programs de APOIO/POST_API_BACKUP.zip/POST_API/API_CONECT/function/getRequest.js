// Get resquest
export class HttpApiConnect{
    // convertJson(response){
    //     JSON.stringify(response);
    // }
    async getJson(http){
        try{
            const response = await fetch(http)
            const jsonData = await response.json();
            return jsonData;

        } catch(erro){
            console.log(erro);
            return 'Deu algo Errado';
        }
    }
    async postJson(http, jsonPOST){

        const options = 
        {
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
            },
            body: JSON.stringify(jsonPOST),
        };
        try{
            const response = await fetch(http, options)

            console.log('Envio para', http);
            console.log('Status do Envio:', response.status);

            if(!response.ok){
                return response.status;
            }else{
                return response
            }
        } catch(erro){
            return 'erro ao postar\n' + erro;
        }

    }
}
    